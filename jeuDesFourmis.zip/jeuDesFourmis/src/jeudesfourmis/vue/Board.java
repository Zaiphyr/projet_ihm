/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jeudesfourmis.vue;

import jeudesfourmis.controller.parameters.SliderBetter;
import jeudesfourmis.controller.parameters.etiquette;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author julie
 */
public class Board extends Application {

    @Override
    public void start(Stage primaryStage) {
        
        Button quit = new Button("Quit");
        quit.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                Platform.exit();
            }
        });
        
        Button loupe = new Button("Loupe");
        
        Button playPause = new Button("Play/Pause");
        
        Button reset = new Button("Reset");
        
        Button init = new Button("Init");
        
        etiquette nbGraine = new etiquette("nombre de graines");
        
        etiquette nbFourmi = new etiquette("nombre de fourmis");
        
        etiquette nbIte = new etiquette("nombre d'itération");
        
        TextField sizePlate = new TextField();
        
        TextField maxGraine = new TextField();
        
        SliderBetter vitesse = new SliderBetter("vitesse", 0, 100, 10);
        
        GridPane plate = new GridPane();
        
        HBox hb_irq = new HBox();
        hb_irq.getChildren().addAll(init, reset, quit);
        
        VBox vb_plate = new VBox();
        vb_plate.getChildren().addAll(plate, hb_irq);
        
        VBox vb_param = new VBox();
        vb_param.getChildren().addAll(loupe, playPause, nbGraine, nbFourmi, nbIte, sizePlate, maxGraine, vitesse);
       
        HBox hb = new HBox();
        hb.getChildren().addAll(vb_plate, vb_param);
        
        StackPane root = new StackPane();
        root.getChildren().add(hb);
        
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
